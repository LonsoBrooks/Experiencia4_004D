
function Mover(obj)
        {
            obj.innerHTML="Durante los últimos 35 años la Tierra ha perdido un tercio de la vida silvestre global. Estados Unidos produce el 30% total de toda la basura del mundo, siendo el país que más contamina. La basura producida anualmente en España equivale a una montaña de las mismas dimensiones que el Mulhacén. Por cada millón de toneladas de petróleo que se transporta en los océanos, cerca de 1 tonelada se derrama en el agua. Se necesitan 9.800 litros de agua para producir un solo filete de carne. Se necesitas 1.500 litros de agua para producir una ración de pollo. Cada 8 segundos muere 1 niño por causas relacionadas con el consumo de agua contaminada.";
            obj.style.background="#39B37E";
            
        }

function MoverFuera(obj)
        {
            obj.innerHTML="Sabias que...";
            obj.style.background= "#39B37E";
            
        }
function CambiaColor(a)
        {
            a.style.background = "#8fbc8f";
        }
function CambiaColor2(a)
        {
            a.style.background = "#90ee90";
        }


function validacion()
        {
            nom= document.getElementById('usuario').value;
            ape= document.getElementById('apellido').value; 
            mail= document.getElementById('mail').value;
            fono = document.getElementById('telefono').value;
            region = document.getElementById('region').value;

            if(nom == null || nom.length==0 || /^\s+$/.test(nom))
            {
                alert('Error.. debe ingresar un nombre');
                document.getElementById('usuario').value="";
                return false;
            }

            if(ape== null || ape.length==0 || /^\s+$/.test(ape))
            {
                alert('Error.. debe ingresar un apellido');
                document.getElementById('apellido').value="";
                return false;
            }
            
         

            if (mail == null || mail == 0)
            {
                alert('Ingrese email');
                return false;
            }

            if(!(/^\d{9}$/.test(fono)) )
            {
                alert('Error...debe ingresar un teléfono válido o completar el campo');
                document.getElementById('telefono').value="";
                return false;
            }
            if(region == null || region.length==0 || /^\s+$/.test(region))
            {
                alert('Error.. debe ingresar una region');
                document.getElementById('region').value="";
                return false;
            }

            return alert("¡Registro completado!");      

            
        }
    

        function iniciarMap(){
            var coord = {lat:-33.428383,lng: -70.6684482};
            var map = new google.maps.Map(document.getElementById('map'),{
              zoom: 10,
              center: coord
            });
            var marker = new google.maps.Marker({
              position: coord,
              map: map
            });
        }

     

function Fechas()
{
    location.href="Feriado.html"
}

