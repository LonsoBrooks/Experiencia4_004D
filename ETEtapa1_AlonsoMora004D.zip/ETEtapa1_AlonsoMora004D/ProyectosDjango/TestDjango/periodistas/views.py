from django.shortcuts import render , redirect
from .models import Usuario
from .forms import UsuarioForm
from django.contrib.auth.decorators import login_required
from rest_framework.serializers import Serializer
from rest_framework import status
from django.views.decorators import csrf
from rest_framework.decorators import api_view, permission_classes 
from rest_framework.response import Response 
from rest_framework.parsers import JSONParser
from django.views.decorators.csrf import csrf_exempt
from .serializers import UsuarioSerializer 

# Create your views here.

def Inicio(request):
    usuarios=Usuario.objects.all() 
    return render(request, 'Inicio.html')


def form_usuario(request):
    if request.method == 'POST': 
        usuario_form = UsuarioForm(request.POST)
        if usuario_form.is_valid():
            usuario_form.save()        #similar al insert de un modelo relacional 
            return redirect('Inicio')
    else: 
        usuario_form = UsuarioForm()
    return render(request, 'periodistas/form_crearusuario.html', {'usuario_form': usuario_form})

@login_required

def form_objeto(request):
    if request.method == "POST":
        usuario_form = UsuarioForm(request.POST,request.FILES)
        if usuario_form.is_valid():
            post = usuario_form.save(commit=False)
            post.save()
            return redirect('Inicio')
    else:
        objeto_form = UsuarioForm()
        return render(request, 'periodistas/form_crearusuario.html', {'usuario_form': objeto_form})



def Ver(request):
    usuarios = Usuario.objects.all()

    return render(request, 'periodistas/ver.html', context={'usuarios':usuarios})

def form_mod_usuario(request,id):
    usuario = Usuario.objects.get(rut=id)

    datos ={
        'form': UsuarioForm(instance=usuario)
    }
    if request.method == 'POST': 
        formulario = UsuarioForm(data=request.POST, instance = usuario)
        if formulario.is_valid: 
            formulario.save()
            return redirect('ver')
    return render(request, 'periodistas/form_mod_usuario.html', datos)

def form_del_usuario(request,id):
    usuario = Usuario.objects.get(rut=id)
    usuario.delete()
    return redirect('ver')


@csrf_exempt
@api_view(['GET', 'POST'])

def lista_usuarios(request): 
    if request.method== 'GET':
        usuario = Usuario.objects.all()
        serializer =UsuarioSerializer(usuario, many=True)
        return Response(serializer.data)

    elif request.method=='POST': 
        data = JSONParser().parse(request)
        serializer = UsuarioSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else: 
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

def lista_api(request):
    return render(request, 'ApiWeb.html')