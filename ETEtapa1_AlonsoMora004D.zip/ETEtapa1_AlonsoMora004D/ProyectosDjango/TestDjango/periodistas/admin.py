from django.contrib import admin
from .models import Pais , Usuario

# Register your models here.

admin.site.register(Pais)
admin.site.register(Usuario)